package com.example.demo;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;


import java.util.Arrays;
import java.util.List;

@Slf4j
@Controller
@RequestMapping
public class DesignTacoController {
    @GetMapping
    public String showDesignForm(Model model) {
        List<Ingrediants> ingredians = Arrays.asList(
                new Ingrediants("FLTO", "Flour Tortilla", Ingrediants.Type.WRAP),
                new Ingrediants("COTO", "COTO Tortilla", Ingrediants.Type.WRAP),
                new Ingrediants("GRBF", "GRBF Tortilla", Ingrediants.Type.PROTEIN),
                new Ingrediants("CARN", "Flour Tortilla", Ingrediants.Type.PROTEIN)
        );
        Ingrediants.Type[] types = Ingrediants.Type.values();
        for (Ingrediants.Type type : types) {
            model.addAttribute(type.toString().toLowerCase());
        }
        //     model.addAttribute("design", new Taco());
    return null;

    }
}